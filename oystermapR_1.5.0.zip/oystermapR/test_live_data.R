# =============================================================================
# test_live_data.R  —  oystermapR live data integration test
# Run from the project root:  source("test_live_data.R")
# =============================================================================

# ---- 0. Auto-install all required packages ----------------------------------

.install_if_missing <- function(pkgs, repos = "https://cloud.r-project.org") {
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) == 0) return(invisible(NULL))
  message("Installing missing packages: ", paste(missing, collapse = ", "))
  install.packages(missing, repos = repos, quiet = TRUE)
}

# Core — needed for load_all() and the package itself to work from source
.install_if_missing(c(
  "devtools",
  "dplyr", "terra", "sf", "rlang", "cli"
))

# Live data — HTTP requests and JSON parsing
.install_if_missing(c("httr", "jsonlite"))

# Spatial interpolation (used by interpolation.R, score functions)
.install_if_missing(c("gstat", "sp"))

# ncdf4: lets terra read coordinate dimensions from CMEMS NetCDF files.
# Without it terra falls back to grid indices (0.5, 1.5, ...) for lat/lon.
.install_if_missing("ncdf4")

# Seasonal scoring and dawn/dusk calculations
.install_if_missing(c("lubridate", "suncalc"))

# Reporting (needed if you call generate_summary_pdf or HTML report)
.install_if_missing(c("ggplot2", "rmarkdown", "knitr"))

# tinytex for PDF rendering — only install the R wrapper, not the full LaTeX
# distribution (user controls that separately via tinytex::install_tinytex())
.install_if_missing("tinytex")

# Python / copernicusmarine — detection checks PATH, common macOS install
# locations (RStudio strips PATH on launch), and python -m fallback.
local({
  # Check direct command on PATH first
  cm_path <- Sys.which("copernicusmarine")
  if (nchar(cm_path) > 0) {
    message("copernicusmarine found on PATH: ", cm_path)
    return()
  }
  # Check common macOS install locations that RStudio misses
  py_versions <- paste0("3.", 8:13)
  candidates <- c(
    "/usr/local/bin/copernicusmarine",
    "/opt/homebrew/bin/copernicusmarine",
    path.expand("~/.local/bin/copernicusmarine"),
    unlist(lapply(py_versions, function(v)
      path.expand(paste0("~/Library/Python/", v, "/bin/copernicusmarine")))),
    path.expand("~/opt/anaconda3/bin/copernicusmarine"),
    path.expand("~/anaconda3/bin/copernicusmarine"),
    path.expand("~/miniconda3/bin/copernicusmarine")
  )
  found <- Filter(file.exists, candidates)
  if (length(found) > 0) {
    message("copernicusmarine found at: ", found[1])
    message("  (not on R's PATH — adding it now for this session)")
    # Add its directory to R's PATH so Sys.which() finds it
    Sys.setenv(PATH = paste(dirname(found[1]), Sys.getenv("PATH"), sep = ":"))
    return()
  }
  # Try python -m import
  for (py in c("python3", "python")) {
    py_path <- Sys.which(py)
    if (nchar(py_path) == 0) next
    ok <- suppressWarnings(
      system2(py_path, c("-c", "import copernicusmarine"),
              stdout = FALSE, stderr = FALSE) == 0L
    )
    if (ok) {
      message("copernicusmarine importable via: ", py_path)
      return()
    }
  }
  message(
    "copernicusmarine not found.\n",
    "  If you installed it, run this in your terminal to find it:\n",
    "    which copernicusmarine\n",
    "  Then paste the directory into Sys.setenv() here, e.g.:\n",
    "    Sys.setenv(PATH = paste('/usr/local/bin', Sys.getenv('PATH'), sep=':'))\n",
    "  Or install it:  pip install copernicusmarine\n",
    "  Without it, oystermapR falls back to the ERDDAP REST endpoint."
  )
})

devtools::load_all(".", quiet = TRUE)
message("Package loaded from source.")

# ---- Quick internet connectivity check --------------------------------------
# If R can't reach the internet, all live sources will fail regardless of URLs.
# This tells us immediately whether the problem is network access or URLs.
cat("\n=== Connectivity check ===\n")
for (url in c("https://cran.r-project.org",
              "https://gis.ices.dk",
              "https://nrt.cmems-du.eu")) {
  result <- tryCatch({
    r <- httr::GET(url, httr::timeout(8))
    paste0("OK (HTTP ", httr::status_code(r), ")")
  }, error = function(e) paste0("FAILED — ", conditionMessage(e)))
  cat(sprintf("  %-38s %s\n", url, result))
}
cat("\n")
# If CRAN fails: R has no internet — check System Preferences > Security & Privacy
# or your firewall. RStudio may need to be allowed network access.
# If CRAN OK but others fail: URL-specific issue, we can fix those.

# ---- 1. CMEMS credentials ---------------------------------------------------
# Register free at https://marine.copernicus.eu (takes ~2 minutes).
# Leave blank to skip CMEMS and only test the open sources.

CMEMS_USER <- "ttucker"
CMEMS_PASS <- "TTcmemsoyster26*"

if (nchar(CMEMS_USER) > 0) {
  oystermapR_live_config(
    cmems_user     = CMEMS_USER,
    cmems_password = CMEMS_PASS,
    show_config    = TRUE
  )
} else {
  message("NOTE: CMEMS_USER is empty — CMEMS test will be skipped.")
}

# ---- 2. Survey area ---------------------------------------------------------
# Fal estuary, SW Cornwall. Swap for your own site.

survey_pts <- data.frame(
  lat = c(50.13, 50.18, 50.22, 50.16, 50.20),
  lon = c(-5.05, -5.00, -4.95, -4.98, -5.02)
)

# ---- 3. Open sources --------------------------------------------------------
# ICES HAB, ICES VMS, EMODnet predators, FSA shellfish classification.
# No credentials needed — runs automatically.

cat("=== Open sources (no credentials needed) ===\n")

open <- withCallingHandlers(
  fetch_live_environmental_data(
    survey     = survey_pts,
    sources    = c("ices_hab", "ices_vms", "emodnet_predators", "fsa_shellfish"),
    date_range = c("2019-01-01", "2024-12-31"),
    verbose    = TRUE
  ),
  warning = function(w) {
    cat("  [WARN]", conditionMessage(w), "\n")
    invokeRestart("muffleWarning")
  }
)

if (length(open) == 0) {
  cat("Nothing returned — likely empty data for this bbox (normal for small inshore areas).\n")
  cat("Check [WARN] lines above for any actual errors.\n")
} else {
  for (nm in names(open)) {
    cat(sprintf("  %-24s %d rows  |  %s\n",
                nm, nrow(open[[nm]]),
                paste(names(open[[nm]]), collapse = ", ")))
  }
}

# ---- 4. CMEMS ---------------------------------------------------------------

if (nchar(CMEMS_USER) > 0) {
  cat("\n=== CMEMS (SST / salinity / chlorophyll) ===\n")
  cat("Method: ",
      if (oystermapR:::.cmems_python_available())
        "Python copernicusmarine CLI"
      else
        "ERDDAP REST (Python/copernicusmarine not found)",
      "\n")

  cmems <- fetch_live_environmental_data(
    survey     = survey_pts,
    sources    = "cmems",
    date_range = c(
      format(Sys.Date() - 14, "%Y-%m-%d"),
      format(Sys.Date(),      "%Y-%m-%d")
    ),
    verbose = TRUE
  )

  if (!is.null(cmems$cmems) && nrow(cmems$cmems) > 0) {
    cat("CMEMS OK —", nrow(cmems$cmems), "rows\n")
    cat("Columns:", paste(names(cmems$cmems), collapse = ", "), "\n")
    print(head(cmems$cmems, 4))
  } else {
    cat("CMEMS returned nothing. Common fixes:\n")
    cat("  Wrong credentials?  Check https://marine.copernicus.eu\n")
    cat("  Python route:       pip install copernicusmarine\n")
    cat("  ERDDAP route:       check https://erddap.marine.copernicus.eu is reachable\n")
  }
} else {
  cat("\n=== CMEMS skipped (fill in CMEMS_USER / CMEMS_PASS above) ===\n")
}

# ---- 5. Full pipeline with live layers --------------------------------------

cat("\n=== Pipeline: predict_oyster() + live layers ===\n")

survey <- read.csv(system.file("extdata", "sample_survey.csv",
                               package = "oystermapR"),
                   stringsAsFactors = FALSE)

baseline <- predict_oyster(survey, species = "ostrea_edulis")
cat("Baseline suitability distribution:\n")
print(table(baseline$suitability_class))

if (!is.null(open$ices_hab) && nrow(open$ices_hab) > 0) {
  r <- score_hab_risk(baseline, species = "ostrea_edulis",
                      hab_data = open$ices_hab)
  cat("\nAfter live HAB layer:\n")
  print(table(r$suitability_class))
}

if (!is.null(open$ices_vms) && nrow(open$ices_vms) > 0) {
  r <- score_anthropogenic_disturbance(baseline,
                                       trawling_data = open$ices_vms)
  cat("\nAfter live trawling (VMS) layer:\n")
  print(table(r$suitability_class))
}

if (!is.null(cmems$cmems) && nrow(cmems$cmems) > 0) {
  cat("\nCMEMS data is ready to use — pass columns into your survey CSV or\n")
  cat("wire directly into score_suitability() via the temperature/salinity/\n")
  cat("chlorophyll_a columns in the returned data frame.\n")
}

cat("\nDone.\n")
