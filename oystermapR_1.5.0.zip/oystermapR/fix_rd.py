#!/usr/bin/env python3
"""Fix non-ASCII degree symbols and broken macros in all man/*.Rd files.
Run from inside the oystermapR package directory:
    python3 fix_rd.py
"""
import os, re, glob, sys

man_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "man")
if not os.path.isdir(man_dir):
    sys.exit(f"ERROR: man/ directory not found at {man_dir}")

changed = 0
for path in sorted(glob.glob(os.path.join(man_dir, "*.Rd"))):
    with open(path, "rb") as f:
        raw = f.read()

    original = raw

    # Fix actual degree symbol (UTF-8 bytes 0xC2 0xB0) — the real cause
    # Order matters: do compound forms before bare degree
    raw = raw.replace("°C".encode("utf-8"),  b"degrees C")
    raw = raw.replace("°N".encode("utf-8"),  b"degrees N")
    raw = raw.replace("°E".encode("utf-8"),  b"degrees E")
    raw = raw.replace("°W".encode("utf-8"),  b"degrees W")
    raw = raw.replace("°".encode("utf-8"),   b"degrees")

    # Fix literal backslash-u sequences that Rd cannot handle (ASCII text)
    raw = raw.replace(b"\\u00b0C", b"degrees C")
    raw = raw.replace(b"\\u00b0N", b"degrees N")
    raw = raw.replace(b"\\u00b0",  b"degrees")
    raw = raw.replace(b"\\u00b",   b"degrees")

    # Fix broken superscript pattern ^-^{-1} -> ^{-1}
    raw = raw.replace(b"^-^{-1}", b"^{-1}")

    # Fix em-dash and en-dash (non-ASCII) -> plain double hyphen
    raw = raw.replace("—".encode("utf-8"), b"--")
    raw = raw.replace("–".encode("utf-8"), b"--")

    # Fix right-arrow
    raw = raw.replace("→".encode("utf-8"), b"->")

    # Fix superscript 2/3
    raw = raw.replace("²".encode("utf-8"), b"^2")
    raw = raw.replace("³".encode("utf-8"), b"^3")

    if raw != original:
        with open(path, "wb") as f:
            f.write(raw)
        fname = os.path.basename(path)
        print(f"  Fixed: {fname}")
        changed += 1

print(f"\n{changed} Rd file(s) updated in {man_dir}")
