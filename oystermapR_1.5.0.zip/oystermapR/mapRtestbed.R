devtools::install("~/Documents/Claude/Projects/oystermapR")
library(oystermapR)
source(system.file("extdata", "test_all_outputs.R", package = "oystermapR"))

pak::cache_clean()
devtools::install("~/Documents/Claude/Projects/oystermapR")
devtools::build("~/Documents/Claude/Projects/oystermapR")
devtools::check_built("oystermapR_1.5.0.tar.gz", args = "--as-cran")
1
devtools::build_vignettes("~/Documents/Claude/Projects/oystermapR")
source("test_live_data.R")

# Store credentials at the start of each R session
# (or add to your .Rprofile to set automatically on startup)
oystermapR_live_config(
  cmems_user     = "2801294t@student.gla.ac.uk",
  cmems_password = "TTcmemsoyster26*",
)

# Check what is configured
oystermapR_live_config(show_config = TRUE)

survey_enriched <- fetch_live_environmental_data(
  survey     = survey,
  sources    = "cmems",     # or "all" for every configured source
  date_range = c("2026-03-01", "2026-03-310"),
  verbose    = TRUE
)
install.packages("EMODnet")

result <- score_predation_risk(
  result,
  fetch_live = TRUE,
  species    = "ostrea_edulis"
)

devtools::check()
devtools::document()
source("test_live_data.R")


tinytex::install_tinytex()


devtools::document()
devtools::check()
devtools::check(remote = TRUE, manual = TRUE)



pkg <- "~/Documents/Claude/Projects/oystermapR"
dir.create(file.path(pkg, "inst", "doc"), recursive = TRUE, showWarnings = FALSE)
rmarkdown::render(
  input      = file.path(pkg, "vignettes", "example-bay-survey.Rmd"),
  output_dir = file.path(pkg, "inst", "doc"),
  output_format = rmarkdown::html_vignette(),
  envir = new.env()
)