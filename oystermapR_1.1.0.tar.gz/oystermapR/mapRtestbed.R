devtools::install("~/Documents/Claude/Projects/oystermapR")
library(oystermapR)
source(system.file("extdata", "test_all_outputs.R", package = "oystermapR"))

pak::cache_clean()
devtools::install("~/Documents/Claude/Projects/oystermapR")
devtools::build("~/Documents/Claude/Projects/oystermapR")

devtools::check(
  pkg     = "~/Documents/Claude/Projects/oystermapR",
  cran    = TRUE,
  remote  = FALSE,
  manual  = TRUE
)